/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
 
string convert(string s)
{
    int n = s.length();
 
    int res_ind = 0;
 
    for (int i = 0; i < n; i++) {
 
        // check for spaces in the sentence
        if (s[i] == ' ') {
 
            // conversion into upper case
            s[i + 1] = toupper(s[i + 1]);
            continue;
        }
 
        else
            s[res_ind++] = s[i];        
    }
 
    return s.substr(0, res_ind);
}
 
int main()
{
    string str = "I am learning DSA from shape AI";
    cout << convert(str);
    return 0;
}
