/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 #include <bits/stdc++.h>
using namespace std;

void rotate(vector<int>& vec, int d)
{
    // Base case
    if (d == 0)
        return;
 
    for (int i = 0; i < d; i++)
    {
        
        vec.push_back(vec[0]);
      
        vec.erase(vec.begin());
    }
 
    for (int i = 0; i < vec.size(); i++)
    {
        cout << vec[i] << " ";
    }
}
 
// Driver code
int main()
{
    vector<int> vec = { 1, 2, 3, 4, 5, 6 };
    int n = vec.size();
    int d = 2;
 
    // Function call
    rotate(vec, d % n);
 
    return 0;
}